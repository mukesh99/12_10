import React, {Component} from 'react';

class FirstComponent extends Component{
    render(){
        return (
            <div>This is first component.</div>
        );
    }
}

export default FirstComponent;