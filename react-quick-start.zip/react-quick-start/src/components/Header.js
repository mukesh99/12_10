import React from 'react';
import ReactDOM from 'react-dom';



class Header extends React.Component{
    render(){ 
      return (
            <div className="header-text">
               <h1>Shopping Cart</h1>
              
                

                </div>
        );
    };
}

export default Header;