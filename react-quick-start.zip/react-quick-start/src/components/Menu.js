import React, {Component} from 'react';

// need to install npm install react-router --save

class Menu extends Component {
    render() {
        return(
            <div className="menu-item">
				<ul>
				
					<li Link to="/">Home</li>
					<li Link to="/first">First</li>
					<li Link to="/cart">Cart</li>
					<li Link to="/">ContactUS</li>
				</ul>
			</div>  
        );
    }
}
export default Menu;