import React, { Component } from 'react';
// import logo from './logo.svg';
import '../App.css';

import Cart from './Cart';
import Header from './Header';
import Items from './Items';
import Footer from './Footer';
import Notfound from './Notfound';

class App extends Component {
  render() {
    
    return (
      <div className="App">
        <header className="App-header">
            <Header/>
        </header>
       
          <Cart/>
        
          <Items/>
             <Footer/>
      </div>
    );
  }
}

export default App;
